<!DOCTYPE html>
<html lang="en">

<?php include_once '../includes/tags/google_tag_manager_head.php';?>
<link rel="icon" type="image/png" href="../img/cropped-favicon-1-32x32.png" sizes="32x32">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <title>Cáncer de Estómago</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" rel="preload" href="../css/normalize.css">
    <link rel="stylesheet" rel="preload" href="../css/style.css">

</head>

<?php include_once '../includes/tags/google_tag_manager_body.php';?>

    <div id="top-header" class="top-header ">
         <a href="tel:+5555238959"><p>Llámanos: (55) 5523 8959</p></a>
    </div>

    <!--####HEADER####-->
    <section id="site-wrapper">
        <!-- CANVAS -->
        <section id="site-canvas">

        <?php include_once '../includes/templates/header_tipos.php';?>
        
        <section>
                <div class="fondo-tipos-de-cancer ">
                    <div class="ocultar-h1">
                        <h1>Cáncer de Estomago</h1>
                    </div>
                    <div class="tipos-cancer-img">
                        <img src="/img/Doctores.webp" alt="">
                    </div>
                </div>
                <div class="tipos-cancer-regresar">
                    <a href="../tipos-de-cancer ">
                            &nbsp; << OTROS TIPOS DE CÁNCER</a>
                    <a href="../contacto ">
                            &nbsp; CONTACTANOS >></a>
                </div>
            </section>

            <div class="secciones mostrar-texto">
                <h2 class="centrar-texto brexia-color font-18 fontW-800 paddingTop-2">Cáncer de Estómago</h2>
                <div class="contenedor-video">
                    <div class="reproductor" data-id="j8Mj1XgzOjY"></div>
                </div>
                <h2 class="centrar-texto brexia-color font-16 fontW-800 paddingBottom-2 ">Secciones de Estómago</h2>
            </div>

            <section class="wrap">
                <div class="tabs-desktop">
                    <ul class="tabs">
                        <li><a href="#tab1">Cáncer de Estómago</a></li>
                        <li><a href="#tab2">Estadísticas</a></li>
                        <li><a href="#tab3">Factores de Riesgo</a></li>
                        <li><a href="#tab4">Tipos</a></li>
                        <li><a href="#tab5">Síntomas</a></li>
                        <li><a href="#tab6">Diagnóstico</a></li>
                        <li><a href="#tab7">Estadificación</a></li>
                        <li><a href="#tab8">Tratamiento</a></li>
                    </ul>
                </div>
                <div class="tabs-movil">
                    <ul class="tabs">
                        <div class="right-movil-tab">
                            <li><a href="#tab1">Cáncer de Estómago</a></li>
                            <li><a href="#tab2">Estadísticas</a></li>
                            <li><a href="#tab3">Factores de Riesgo</a></li>
                            <li><a href="#tab4">Tipos</a></li>
                        </div>
                        <div class="left-movil-tab">
                            <li><a href="#tab5">Síntomas</a></li>
                            <li><a href="#tab6">Diagnóstico</a></li>
                            <li><a href="#tab7">Estadificación</a></li>
                            <li><a href="#tab8">Tratamiento</a></li>
                        </div>
                    </ul>
                </div>

                <div class="secciones ocultar-text">
                    <h2 class="centrar-texto brexia-color font-18 fontW-800">Cáncer de Estomago</h2>

                    <div class="contenedor-video">
                        <div class="reproductor" data-id="j8Mj1XgzOjY"></div>
                    </div>
                </div>


                <div class="secciones">
                    <article id="tab1">
                    <h2 class="centrar-texto brexia-color font-18 fontW-800 paddingTop-1 paddingBottom-1">¿Qué es el Cáncer de Estomago?</h2>
                        <div class="font-16 fontW-400">
                            <p>El cáncer de estómago es un tipo de cáncer que se forma en los tejidos que revisten el estómago. La mayoría comienza en las células de la capa interna del estómago (la mucosa), que suele elaborar y secretar moco y otros líquidos.
                                Estos tipos de cáncer se llaman adenocarcinomas y representan el 90% de los casos de cáncer de estómago.</p>

                            <div class="imagen-80 centrar-imagen">
                                <img src="/img/Dommie-cancer/Brexia-Canceres-ESTOMAGO.webp" alt="Brexia_especialistas">
                            </div>

                            <p>El estómago es un órgano con forma de “J” ubicado en la parte superior del abdomen. Es parte del aparato digestivo, que procesa los nutrientes (vitaminas, minerales, carbohidratos, grasas, proteínas y agua) de los alimentos
                                y ayuda a eliminar los materiales de desecho del cuerpo. Los alimentos pasan de la garganta al estómago a través de un tubo muscular y hueco que se llama esófago. Después de salir del estómago, los alimentos parcialmente
                                digeridos pasan al intestino delgado y luego, al intestino grueso.</p>
                            
                            <p>La pared del estómago se compone de cinco capas de tejido. De la capa más interna a la más externa, las capas de la pared del estómago son las siguientes: mucosa, submucosa, músculo, subserosa (tejido conjuntivo) y serosa.
                                El cáncer de estómago comienza en la mucosa y a medida que crece se disemina a las otras capas del estómago.</p>
                            <p>Los tumores de estroma surgen en el tejido conjuntivo que sostiene el estómago y se tratan de manera diferente al cáncer de estómago.</p>
                            <div class="imagen-80 centrar-imagen">
                                <img src="/img/cancer-de-estomago/Tipos_cancer_de_estomago-1-768x512.webp" alt="Brexia_especialistas">
                            </div>
                            <p>En Brexia nuestros oncólogos médicos y oncólogos quirúrgicos tienen años de experiencia en el tratamiento del cáncer de estómago. Nuestro modelo de atención integral también está diseñado para satisfacer las necesidades nutricionales
                                de los pacientes, controlar su dolor y abordar otros efectos secundarios a lo largo de su viaje de tratamiento.</p>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Puntos Importantes del Cáncer de Estómago</h2>
                            <ul class="secciones-enumeradas">
                                <li>El cáncer de estómago es una enfermedad por la que se forman células malignas (cancerosas) en el revestimiento del estómago.</li>
                                <li>La edad, la alimentación y las enfermedades del estómago afectan el riesgo de cáncer de estómago.</li>
                                <li>Los síntomas del cáncer de estómago incluyen indigestión y malestar o dolor estomacal.</li>
                                <li>Para detectar (encontrar) y diagnosticar el cáncer de estómago, se utilizan pruebas que examinan el estómago y el esófago.</li>
                                <li>Ciertos factores afectan el pronóstico (probabilidad de recuperación) y las opciones de tratamiento.</li>
                            </ul>
                        </div>
                    </article>
                    <article id="tab2">
                        <h2 class="centrar-texto brexia-color encabezados-brexia ">Estadísticas del Cáncer de Estómago</h2>
                        <div class="font-16 fontW-400">
                            <p>Cuando usted se entera de que tiene cáncer de estómago y comienza a buscar opciones de tratamiento, es posible que le preocupe sobre todo su esperanza de vida y su calidad de vida. En Brexia creemos que tiene derecho a conocer
                                las estadísticas sobre los resultados del tratamiento del cáncer de estómago, para que pueda tomar decisiones informadas sobre su atención del cáncer.</p>
                            <p>El diagnóstico de cáncer de cada persona es tan distinto como la persona que padece. Parte de nuestra promesa en Brexia para usted y su familia es ofrecer información clara y opciones de tratamiento potentes, todo en función
                                de sus necesidades individuales.</p>
                            <p>Muchos pacientes con cáncer de estómago consideran que la duración y la calidad de vida son dos de las estadísticas más importantes para la atención del cáncer de estómago, y valoran una experiencia de tratamiento que sea lo
                                más conveniente y libre de estrés posible.</p>
                            <p>En todo el mundo, el cáncer de estómago es más habitual en Asia oriental, América del Sur y Europa oriental; es menos frecuente en Europa occidental, aunque es el quinto más frecuente del continente. La marcada variación en
                                la frecuencia del cáncer de estómago entre continentes y países se debe principalmente a diferencias en la alimentación y a los factores genéticos.</p>
                            <p>Las estadísticas mostradas a continuación provienen de los Estados Unidos ya que por el momento en México contamos con un subregistro de información. (cáncer.gov).</p>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Estadísticas Generales</h2>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Cancer-de-Estomago-01-768x554.webp" alt="Brexia_especialistas">
                            </div>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Casos nuevos vs Defunciones</h2>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Cancer-de-Estomago-768x590.webp" alt="Brexia_especialistas">
                            </div>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Supervivencia del Cáncer de Estomago</h2>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Supervivencia_Cancer-de-Estomago-768x629.webp" alt="Brexia_especialistas">
                            </div>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Número de casos por Estudio</h2>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Cancer-de-Estomago_grafica-768x474.webp" alt="Brexia_especialistas">
                            </div>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Cancer-de-Estomago_Brexia-768x632.webp" alt="Brexia_especialistas">
                            </div>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">¿Qué tan común es este cáncer?</h2>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Cancer-de-Estomago_BREXIA_especialistas-768x576.webp" alt="Brexia_especialistas">
                            </div>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Casos_Cancer-de-Estomago-768x845.webp" alt="Brexia_especialistas">
                            </div>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Porcentaje de casos nuevos por grupo de edad:</h2>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/porcentaje_nuevos_casos-768x552.webp" alt="Brexia_especialistas">
                            </div>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/estadisticas_Cancer-de-Estomago-768x359.webp" alt="Brexia_especialistas">
                            </div>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Porcentaje de muertes por grupo de edad</h2>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Porcentaje-de-muertes_Cancer-de-Estomago-768x517.webp" alt="Brexia_especialistas">
                            </div>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/cifras_muertes_Cancer-de-Estomago-768x324.webp" alt="Brexia_especialistas">
                            </div>
                        </div>
                    </article>
                    <article id="tab3">
                        <h2 class="centrar-texto brexia-color encabezados-brexia ">Factores de Riesgo del Cáncer de Estómago</h2>
                        <div class="font-16 fontW-400">
                            <p>Hoy en día no está claro por qué se produce el cáncer de estómago, aunque se han identificado algunos factores de riesgo. Un factor de riesgo aumenta el riesgo de aparición de cáncer, pero no es suficiente ni necesario para
                                causarlo. No es una causa en sí mismo. La mayoría de las personas con estos factores de riesgo nunca padecerá cáncer de estómago, mientras que algunas personas sin dichos factores de riesgo si lo harán.</p>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/factores_riesgo_cancer_de_estomago-768x512.webp" alt="Brexia_especialistas">
                            </div>
                            <p>Los principales factores de riesgo de cáncer de estómago son:</p>
                            <p>Factores ambientales:</p>
                            <ul class="secciones-enumeradas">
                                <li>Helicobacter pylori: es una bacteria que puede residir en el estómago y provocar inflamación crónica o úlceras. Si esta situación continúa durante algunas décadas, puede desarrollarse cáncer. Sin embargo, la infección atravesará
                                    primero diversos estadios precancerosos (como gastritis atrófica, metaplasia y displasia) que podrían convertirse en cáncer, pero no siempre es el caso. Estos estadios pueden detectarse y tratarse antes de que puedan
                                    evolucionar y convertirse en cáncer. Si se dejan sin tratar, el 1 % de todos los pacientes con H. pylori sufrirá cáncer de estómago. Aproximadamente el 50 % de la población mundial está infectada con H. pylori. La transmisión
                                    se produce por medio de las heces y la saliva, y está muy relacionada con un estatus socioeconómico bajo y malas condiciones de vida. El tratamiento de esta infección consiste en una cura con antibióticos. La infección
                                    con H. pylori es el factor de riesgo más importante para el cáncer de estómago y tiene tratamiento eficaz.</li>
                            </ul>
                            <p>Factores ambientales:</p>
                            <ul class="secciones-enumeradas">
                                <li>Estilo de vida:</li>
                                <li>Una ingesta elevada de sal, incluyendo los salazones (como alimentos ahumados o conservados en sal), aumenta en gran medida el riesgo de aparición de cáncer de estómago. La presencia de sal aumenta la probabilidad de aparición
                                    de una infección con H. pylori y también parece agravar el efecto de la infección. Además, daña la mucosa gástrica y puede, de ese modo, contribuir directamente a la aparición del cáncer de estómago.</li>
                                <li>Una ingesta elevada de alimentos que contengan nitratos o nitritos, como la carne en conserva, puede aumentar el riesgo de aparición de cáncer de estómago.</li>
                                <li>Comer frutas y vegetales que contengan las vitaminas A y C ha demostrado proteger de forma significativa contra la aparición del cáncer de estómago.</li>
                                <li>Tabaco: La tasa de cáncer de estómago casi se duplica en los fumadores.</li>
                                <li>Ocupación: Los trabajadores en los sectores del carbón, metal y caucho parecen presentar un riesgo ligeramente mayor de aparición de cáncer de estómago. </li>
                                <li>Actividad Fisica: Algunos estudios han demostrado que las personas que realizan mucha actividad física pueden reducir su riesgo de aparición de cáncer de estómago a la mitad.</li>
                            </ul>
                            <p>Factores que no pueden modificarse:</p>
                            <ul class="secciones-enumeradas">
                                <li>Algunos trastornos genéticos pueden aumentar el riesgo de aparición del cáncer de estómago.</li>
                                <li>Sexo: El cáncer de estómago es más frecuente en hombres que en mujeres. Las razones de esta diferencia no están claras, pero puede que la hormona femenina estrógeno produzca un efecto protector.</li>
                            </ul>
                            <p>Trastornos médicos:</p>
                            <ul class="secciones-enumeradas">
                                <li>Tratamientos previos: Las personas que han recibido tratamiento por otro tipo de cáncer de estómago conocido como linfoma del tejido linfoide asociado a las mucosas (MALT) presentan un aumento del riesgo de sufrir adenocarcinoma
                                    de estómago.</li>
                                <li>Tratamientos previos: Las personas que han recibido tratamiento por otro tipo de cáncer de estómago conocido como linfoma del tejido linfoide asociado a las mucosas (MALT) presentan un aumento del riesgo de sufrir adenocarcinoma
                                    de estómago.</li>
                                <li>Cirugía previa del estómago: Cuando se ha extirpado parte del estómago, por ejemplo, a causa de una úlcera de estómago, hay una mayor probabilidad de aparición de cáncer en la parte que queda. Esto puede deberse a que se
                                    produce menos ácido gástrico, la disminución del ácido gástrico puede permitir la proliferación de las bacterias en el estómago, lo que puede contribuir a la elaboración de más productos químicos que pueden aumentar
                                    el riesgo de cáncer de estómago.</li>
                                <li>Los pólipos gástricos: Son bultos benignos en el revestimiento interno del estómago. Un tipo de pólipo, que se denomina adenoma, puede en ocasiones convertirse en cáncer. Los adenomas pueden detectarse y extirparse durante
                                    una gastroscopia, que es una exploración del estómago en la que el médico hace pasar un tubo delgado, flexible y emisor de luz, denominado endoscopio, por la garganta hacia el estómago del paciente.</li>
                                <li>La anemia perniciosa: Es un trastorno en el que los pacientes no absorben suficiente vitamina B12 de los alimentos. La vitamina B12 es necesaria para la elaboración de nuevos eritrocitos (glóbulos rojos de la sangre). Junto
                                    con la anemia (bajas cantidades de eritrocitos o glóbulos rojos), el riesgo de cáncer de estómago también aumenta para estos pacientes.</li>
                            </ul>
                            <p>Se sospecha que puede haber otros factores asociados con un aumento del riesgo de cáncer de estómago, como obesidad, infección por el virus de Epstein-Barr (que produce la mononucleosis infecciosa) y un trastorno raro denominado
                                enfermedad de Ménétrier. Sin embargo, la evidencia no es concluyente y el mecanismo continúa siendo poco claro.</p>
                        </div>
                    </article>
                    <article id="tab4">
                        <h2 class="centrar-texto brexia-color encabezados-brexia ">Tipos de Cáncer de Estómago</h2>
                        <div class="font-16 fontW-400">
                            <p>Los diferentes tipos de cáncer de estómago incluyen:</p>
                            <ul class="secciones-enumeradas">
                                <li>Los adenocarcinomas del estómago se desarrollan en las células del revestimiento más interno del estómago. La mayoría de los cánceres de estómago se clasifican como adenocarcinomas del estómago.</li>
                                <li>El linfoma es un cáncer del tejido del sistema inmunitario que puede comenzar en cualquier lugar donde se encuentren tejidos linfáticos, incluido el estómago. Los linfomas en el estómago son bastante raros y solo representan
                                    alrededor del 4 por ciento de todos los cánceres de estómago.</li>
                            </ul>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Tipos_cancer_de_estomago-768x512.webp" alt="Brexia_especialistas">
                            </div>
                            <ul class="secciones-enumeradas">
                                <li>Los tumores del estroma gastrointestinal, o GIST, son un tipo raro de cáncer de estómago que se forma en una célula especial que se encuentra en el revestimiento del estómago llamada células intersticiales de Cajal (ICC).
                                    Bajo un microscopio, las células GIST se parecen a las células musculares o nerviosas. Estos tumores pueden desarrollarse en todo el tracto digestivo, pero alrededor del 60 al 70 por ciento ocurren en el estómago.</li>
                                <li>Los tumores carcinoides generalmente comienzan en las células productoras de hormonas del estómago. Estos tumores generalmente no se propagan a diferentes órganos y representan solo alrededor del 3 por ciento de la incidencia
                                    de cáncer de estómago. Los tumores carcinoides gástricos vienen en tres tipos:</li>
                                <li>Los carcinoides de células ECL tipo I y II rara vez se propagan a otras partes del cuerpo y pueden no producir síntomas. Con mayor frecuencia se descubren durante una endoscopia por otro problema de salud, como el reflujo
                                    ácido.
                                </li>
                                <li>Los carcinoides de células ECL tipo III son más agresivos. El exceso de secreción hormonal de los tumores carcinoides puede conducir a una afección llamada síndrome carcinoide, marcada por enrojecimiento, dolor abdominal,
                                    diarrea, constricción de los bronquios en los pulmones y, en algunos casos, problemas cardíacos como disfunción valvular. El síndrome carcinoide es una señal de que puede requerirse un tratamiento más agresivo.
                                </li>
                            </ul>
                        </div>
                    </article>
                    <article id="tab5">
                        <h2 class="centrar-texto brexia-color encabezados-brexia ">Síntomas del Cáncer de Estómago</h2>
                        <div class="font-16 fontW-400">
                            <p>La mayoría de los pacientes con cáncer de estómago en etapa temprana no tienen síntomas de la enfermedad. En otros casos, los pacientes con cáncer de estómago pueden confundir sus síntomas con un virus estomacal común. Cuando
                                los signos y síntomas del cáncer de estómago no son aparentes, la enfermedad puede alcanzar etapas avanzadas antes de que se haga un diagnóstico.</p>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Sintomas_Cancer-de-Estomago-768x512.webp" alt="Brexia_especialistas">
                            </div>
                            <p>Por eso es importante que los pacientes considerados de alto riesgo hablen con sus médicos sobre los síntomas que pueden ser signos de un tumor estomacal. Los primeros síntomas de cáncer de estómago pueden incluir.</p>
                            <ul class="secciones-enumeradas">
                                <li>Sentirse lleno: muchos pacientes con cáncer de estómago experimentan una sensación de "plenitud" en la parte superior del abdomen después de comer comidas pequeñas.</li>
                                <li>Acidez estomacal: indigestión, acidez estomacal o síntomas similares a una úlcera pueden ser signos de un tumor estomacal.</li>
                                <li>Náuseas y vómitos: algunos pacientes con cáncer de estómago tienen síntomas que incluyen náuseas y vómitos. A veces, el vómito contiene sangre.</li>
                            </ul>
                            <p>Otros síntomas comunes del cáncer de estómago pueden incluir:</p>
                            <ul class="secciones-enumeradas">
                                <li>Pérdida de peso inexplicable: la falta de apetito o la pérdida de peso inexplicable es un signo común de cáncer.</li>
                                <li>Dolor de estómago: las molestias abdominales o el dolor en el abdomen por encima del ombligo pueden ser un síntoma de un tumor de estómago. Además, la inflamación o la acumulación de líquido en el abdomen también pueden
                                    ser causadas por cáncer de estómago.</li>
                            </ul>
                        </div>
                    </article>
                    <article id="tab6">
                        <h2 class="centrar-texto brexia-color encabezados-brexia ">Diagnóstico del Cáncer de Estómago</h2>
                        <div class="font-16 fontW-400">
                            <p>Puede sospecharse cáncer de estómago en diversas circunstancias. Por desgracia, las señales suelen ser vagas y muy comunes, pueden indicar muchos otros trastornos médicos. En la fase temprana, el cáncer de estómago no causa
                                ningún síntoma. Por lo tanto, con frecuencia no se sospecha tumor gástrico. En el caso de que se produzca una combinación de las quejas que se indican a continuación, especialmente si son persistentes, debe considerarse
                                la posibilidad de realizar exploraciones más en profundidad:</p>
                            <ul class="secciones-enumeradas">
                                <li>Molestias o dolor abdominal.</li>
                                <li>Sensación de plenitud, incluso después de una comida escasa.</li>
                                <li>Acidez, indigestión, eructos y acidez.</li>
                                <li>Náuseas y/o vómitos, especialmente con sangre.</li>
                                <li>Hinchazón o acumulación de líquido en el abdomen.</li>
                                <li>Falta de apetito.</li>
                                <li>Pérdida de peso sin razón aparente.</li>
                                <li>Las pequeñas pérdidas de sangre por el estómago también pueden provocar anemia que a su vez produce cansancio y dificultad para respirar o falta de aliento.</li>
                            </ul>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Etapas_Cancer-de-Estomago-768x512.webp" alt="Brexia_especialistas">
                            </div>
                            <p>En Japón y Corea, donde hay un número elevado de casos nuevos de cáncer de estómago, se propone un cribado (screening) para todas las personas a los 50 años y un seguimiento de conformidad con el resultado de la exploración
                                de cribado.</p>
                            <p>En México no se ha propuesto ningún cribado similar, porque el número de casos de cáncer de estómago nuevos no se considera suficiente como para que sea eficaz.</p>
                            <p>El diagnóstico de cáncer de estómago se basa en distintas exploraciones.</p>
                            <ul class="secciones-enumeradas">
                                <li>Exploración médica: El médico explorará el abdomen para identificar toda hinchazón o dolor anómalos. También comprobará que no haya ninguna hinchazón anómala por encima que podría deberse a una diseminación del cáncer a
                                    los ganglios linfáticos.</li>
                                <li>Exploración endoscópica: Durante una exploración endoscópica del tubo digestivo superior o gastroscopia, el médico hace pasar un tubo delgado, flexible y emisor de luz denominado endoscopio por la garganta del paciente
                                    hasta el estómago. Esto permite al médico ver el revestimiento del esófago, el estómago y la primera parte del intestino delgado. Si se observan zonas anómalas, pueden tomarse biopsias (muestras de tejido) usando los
                                    instrumentos que se introducen por el endoscopio. Un especialista examinará en el laboratorio estas muestras de tejido. Durante la gastroscopia puede realizarse una ultrasonido endoscópico, en la que se introduce una
                                    sonda ultrasónica por la garganta hasta el estómago para ofrecer imágenes de las diferentes capas de la pared gástrica (del estómago), así cómo de los ganglios linfáticos y otras estructuras cercanas. Esta técnica se
                                    usa para ver la diseminación del cáncer en la pared gástrica, en los tejidos cercanos o en los ganglios linfáticos cercanos. También puede guiar a los médicos en la extracción de una pequeña muestra (biopsia) de una
                                    lesión sospechosa durante la gastroscopia.</li>
                                <li>Exploración radiológica: Una tomografía (TAC) muestra la extensión del cáncer, tanto a nivel local como en otras partes del cuerpo. También puede usarse para guiar una biopsia. Pueden realizarse también examenes adicionales,
                                    como radiografías y exploraciones mediante tomografía por emisión de positrones (PET), para excluir la diseminación a distancia de la enfermedad, que se conoce como metástasis.</li>
                                <li>Examen histopatológico: Un patólogo examinará en el laboratorio la muestra de la biopsia (la muestra de tejido extraído durante la gastroscopia), lo que se conoce como examen histopatológico. Usando un microscopio y varias
                                    otras pruebas, el patólogo confirmará el diagnóstico de cáncer y proporcionará más información sobre sus características. El examen histopatológico también puede realizarse en muestras obtenidas durante una laparoscopia,
                                    en el líquido usado para un lavado peritoneal o en el tumor extraído durante una operación quirúrgica.</li>
                                <li>Laparoscopia: Suele realizarse una laparoscopia una vez que el cáncer de estómago ya se ha diagnosticado y se prevé una operación quirúrgica. Contribuye a confirmar que el cáncer se encuentra únicamente en el estómago y,
                                    por lo tanto, puede eliminarse por completo mediante una operación quirúrgica. Durante esta intervención, se inserta un tubo flexible y delgado a través de una pequeña apertura quirúrgica en el abdomen del paciente.
                                    Tiene una pequeña cámara en un extremo, mediante la cual los médicos pueden observar de cerca las superficies de los órganos y ganglios linfáticos cercanos, además de tomar pequeñas muestras de tejido para comprobar
                                    la existencia de posibles metástasis. En ocasiones, los cirujanos vierten líquido en la cavidad abdominal, lo extraen mediante aspiración y lo envían al laboratorio para comprobar la existencia de células cancerosas.
                                    Esto se conoce como lavado peritoneal.</li>
                            </ul>
                        </div>
                    </article>
                    <article id="tab7">
                        <h2 class="centrar-texto brexia-color encabezados-brexia ">Estadificación del Cáncer de Estómago</h2>
                        <div class="font-16 fontW-400">
                            <p>Tomar una decisión de tratamiento educada comienza con la estadificaión de la etapa o progresión de la enfermedad. La etapa del cáncer de estómago es uno de los factores más importantes para evaluar las opciones de tratamiento.</p>
                            <p>Nuestros médicos especialistas en cáncer usan una variedad de pruebas de diagnóstico para evaluar el cáncer de estómago y desarrollar un plan de tratamiento individualizado. Si le diagnosticaron recientemente, revisaremos su
                                patología para confirmar que ha recibido un diagnóstico y estadificación correctos, y desarrollaremos un plan de tratamiento personalizado. Si tiene una recurrencia, realizaremos pruebas exhaustivas y desarrollaremos un
                                plan de tratamiento adaptado a sus necesidades.</p>
                            <p>El proceso de estadificación es una base para seleccionar las opciones de tratamiento y ayudar a los médicos a comunicar los posibles resultados (pronóstico). El sistema TNM considera tres factores importantes:</p>
                            <p>&nbsp;T (tumor): describe el tamaño y el crecimiento del tumor primario de estómago.</p>
                            <p>&nbsp; N (nodo): proporciona información sobre el cáncer de estómago que se encuentra en los ganglios linfáticos regionales.</p>
                            <p>&nbsp; M (metástasis): indica si el cáncer ha hecho metástasis o se ha diseminado a otras áreas.</p>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Etapas del Cáncer de Estómago</h2>
                            <p>Cada una de estas categorías se clasifica en una escala numerada, con los números más altos que indican una mayor gravedad. Estas categorías se agrupan en etapas de cáncer de estómago de 0 a IV:</p>
                            <p>Etapa 0: el cáncer de estómago en etapa temprana también se conoce como carcinoma in situ, porque el cáncer no se ha diseminado a ningún tejido cercano. En esta etapa, el cáncer aún no se ha diseminado a la capa interna de
                                células que recubren el estómago.</p>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/Etapas_cancer_estomago-768x512.webp" alt="Brexia_especialistas">
                            </div>
                            <p>Etapa I (etapa 1 del cáncer de estómago): esta etapa del cáncer de estómago se divide en dos categorías:</p>
                            <ul class="secciones-enumeradas">
                                <li>El cáncer de estómago en etapa IA ocurre cuando el cáncer ha crecido debajo de la capa superior de células en la mucosa pero no ha crecido en la capa muscular principal del estómago. El cáncer no se ha diseminado a ningún
                                    ganglio linfático ni a ningún otro lugar.</li>
                                <li>El cáncer de estómago en etapa IB ocurre cuando se cumple una de las siguientes condiciones: Se cumplen las condiciones de la etapa IA y el cáncer también se ha diseminado a uno o dos ganglios linfáticos cerca del estómago,
                                    pero no a otros tejidos u órganos. O el cáncer ha crecido hacia la capa muscular principal de la pared del estómago, pero no se ha propagado a los ganglios linfáticos, tejidos u órganos cercanos.</li>
                            </ul>
                            <p>Etapa II (etapa 2 del cáncer de estómago): esta etapa del cáncer de estómago se divide en dos categorías:</p>
                            <ul class="secciones-enumeradas">
                                <li>El cáncer de estómago en etapa IIA ocurre cuando se cumple una de las siguientes condiciones:</li>
                                <li>El cáncer ha crecido debajo de la capa superior de células. No ha alcanzado la capa muscular principal, pero se ha extendido a entre tres y seis ganglios linfáticos cerca del estómago. Los sitios distantes no han sido afectados.</li>
                                <li>El cáncer se ha convertido en la capa muscular principal del estómago. Se ha diseminado a uno o dos ganglios linfáticos cercanos, pero no se ha extendido a sitios distantes.</li>
                                <li>El cáncer ha crecido a través de la capa muscular principal hacia la subserosa, pero no ha crecido a través de todas las capas hacia el exterior del estómago. No se ha propagado a ningún ganglio linfático, tejido u órgano
                                    cercano fuera del estómago.</li>
                                <li>La etapa IIB ocurre cuando se cumple una de las siguientes condiciones:</li>
                                <li>El cáncer ha crecido debajo de la capa superior de células pero no dentro de la capa muscular principal. Se ha diseminado a siete o más ganglios linfáticos cerca del estómago. Los tejidos y órganos fuera del estómago no
                                    se ven afectados.</li>
                                <li>El cáncer se ha convertido en la capa muscular principal. Se ha diseminado a entre tres y seis ganglios linfáticos cerca del estómago, pero no se ha extendido a ningún tejido u órgano fuera del estómago.</li>
                                <li>El cáncer ha crecido hacia la capa subserosa, pero no completamente a través de todas las capas hacia el exterior del estómago. Se ha diseminado a uno o dos ganglios linfáticos cercanos, pero no se ha extendido a tejidos
                                    u órganos fuera del estómago.</li>
                                <li>El cáncer ha crecido completamente a través de todas las capas de la pared del estómago hacia la cubierta externa del estómago, pero no ha comenzado a crecer en otros órganos o tejidos cercanos. No se ha propagado a ningún
                                    ganglio linfático cercano ni a sitios distantes.</li>
                            </ul>
                            <p>Etapa III (etapa 3 del cáncer de estómago): esta etapa del cáncer de estómago se divide en tres categorías:</p>
                            <ul class="secciones-enumeradas">
                                <li>La etapa IIIA ocurre cuando se cumple una de las siguientes condiciones:</li>
                                <li>El cáncer se ha convertido en la capa muscular principal del estómago. Se ha diseminado a siete o más ganglios linfáticos, pero no se ha extendido a tejidos u órganos fuera del estómago.</li>
                                <li>El cáncer ha crecido hacia la capa subserosa, pero no completamente a través de todas las capas hacia el exterior del estómago. Se ha diseminado a entre tres y seis ganglios linfáticos cercanos, pero no se ha extendido
                                    a tejidos u órganos fuera del estómago.</li>
                                <li>El cáncer ha crecido completamente a través de todas las capas de la pared del estómago hacia la cubierta externa del estómago, pero no ha comenzado a crecer en órganos o tejidos cercanos. Se ha diseminado a uno o dos ganglios
                                    linfáticos cercanos, pero no se ha extendido a sitios distantes.</li>
                                <li>La etapa IIIB ocurre cuando se cumple una de las siguientes condiciones:</li>
                                <li>El cáncer ha crecido hacia la capa subserosa, pero no completamente a través de todas las capas hacia el exterior del estómago. Se ha diseminado a siete o más ganglios linfáticos cercanos, pero no se ha extendido a sitios
                                    distantes.
                                </li>
                                <li>El cáncer ha crecido completamente a través de todas las capas de la pared del estómago hacia la serosa, pero no ha comenzado a crecer en órganos o tejidos cercanos. Se ha diseminado de tres a seis ganglios linfáticos cercanos,
                                    pero no se ha extendido a sitios distantes.</li>
                                <li>El cáncer ha crecido a través de la pared del estómago y hacia los órganos o estructuras cercanos. También puede haberse propagado a hasta dos ganglios linfáticos cercanos. No se ha extendido a sitios distantes.</li>
                                <li>La etapa IIIC ocurre cuando se cumple una de las siguientes condiciones:</li>
                                <li>El cáncer ha crecido completamente a través de todas las capas de la pared del estómago hacia la serosa, pero no ha comenzado a crecer en órganos o tejidos cercanos. Se ha diseminado a siete o más ganglios linfáticos cercanos
                                    (N3) pero no se ha extendido a sitios distantes.</li>
                                <li>El cáncer ha crecido a través de la pared del estómago y hacia los órganos o estructuras cercanos. Se ha diseminado a tres o más ganglios linfáticos cercanos. No se ha extendido a sitios distantes.</li>
                            </ul>
                            <p>Etapa IV (cáncer de estómago en etapa 4): esta es la forma más avanzada de la enfermedad. En el estadio IV, el cáncer ha hecho metástasis o se ha diseminado, más allá del estómago, a otras áreas del cuerpo. La tasa de supervivencia
                                a cinco años para las personas diagnosticadas con cáncer de estómago en etapa IV es del 4 por ciento.</p>
                        </div>
                    </article>
                    <article id="tab8">
                        <h2 class="centrar-texto brexia-color encabezados-brexia ">Tratamiento del Cáncer de Estómago</h2>
                        <div class="font-16 fontW-400">
                            <p>En Brexia nuestros oncólogos médicos y oncólogos quirúrgicos tienen años de experiencia en el tratamiento del cáncer de estómago. Nuestro modelo de atención integral también está diseñado para satisfacer las necesidades nutricionales
                                de los pacientes, controlar su dolor y abordar otros efectos secundarios a lo largo de su viaje de tratamiento. </p>
                            <div class="imagen-80 centrar-imagen ">
                                <img src="/img/cancer-de-estomago/factores_riesgo_cancer_de_estomago-768x512.webp" alt="Brexia_especialistas">
                            </div>
                            <p>Las opciones de tratamiento del cáncer de estómago varían ampliamente dependiendo de varios factores, incluyendo la etapa, el tipo y la progresión de la enfermedad. Nuestros expertos en cáncer están capacitados y tienen experiencia
                                en los tratamientos disponibles, y se mantienen actualizados sobre las opciones y tecnologías nuevas y emergentes. Las opciones más comunes para tratar cáncer de estómago son:</p>
                            <p>La planificación del tratamiento implica un equipo multidisciplinario de profesionales médicos. Esto suele implicar una reunión de los diferentes especialistas, que se conoce como opinión multidisciplinaria o revisión del comité
                                de tumores. En esta reunión se discute la planificación del tratamiento de acuerdo con la información relevante que se indicó antes. En una revisión del comité de tumores suelen participar un médico oncólogo (que proporciona
                                tratamiento del cáncer con fármacos), un cirujano oncólogo (que trata el cáncer con cirugía), un radio-oncólogo (que trata el cáncer con radiación), un gastroenterólogo (especialista en enfermedades del estómago y de los
                                intestinos), un radiólogo y un patólogo.</p>
                            <p>Como primer paso, este equipo decidirá si el cáncer de estómago es operable (resecable), lo cual implica que es posible extirpar el tumor completo en una operación o no operable (no resecable), lo cual implica que esto no es
                                posible. Un tumor considerado como operable pudo haber invadido también estructuras que rodean el estómago, pero estas pueden extirparse sin complicaciones. Un tumor puede ser no resecable porque ha crecido demasiado hacia
                                órganos o ganglios linfáticos cercanos, porque ha invadido en gran medida los vasos sanguíneos cercanos o porque se ha extendido a partes distantes del cuerpo. No hay una línea divisoria definida entre resecable y no resecable,
                                en términos del estadio del cáncer, pero los cánceres en estadio más temprano tienen más probabilidades de ser resecables.</p>
                            <p>La cirugía es el único tratamiento que se realiza con el objetivo de curar el cáncer. Si esto no es posible, los demás tratamientos se utilizan con el objetivo de aliviar los síntomas y prolongar la vida del paciente.</p>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Plan de tratamiento para la enfermedad localizada (estadios 0 a III y resecable)</h2>
                            <p>Tratamiento endoscópico: Puede realizarse resección endoscópica de la mucosa (REM) en cánceres limitados a la capa interna del estómago o la mucosa, habitualmente en cánceres pequeños sin úlceras. El médico pasará un pequeño
                                tubo por la garganta hasta llegar al estómago (como se hace durante una gastroscopia) y extirpará el tumor.</p>
                            <p>Cirugía: Durante una operación, los cirujanos extirparán el tumor con parte del estómago o con el estómago en su totalidad. La cantidad de tejido que va a extirparse depende del estadio de la enfermedad. Es importante extirpar
                                el tumor con un margen definido de estómago sano y junto con los ganglios linfáticos cercanos al estómago.</p>
                            <p>Terapia adyuvante: Un tratamiento adyuvante es un tratamiento administrado además de la operación quirúrgica. Un tratamiento adyuvante puede tratarse de quimioterapia, bien por sí sola o en combinación con radioterapia. Los
                                tratamientos adyuvantes pueden comenzarse antes (neoadyuvantes) o después de la operación quirúrgica. El objetivo de las terapias adyuvantes es reducir el tamaño del tumor y facilitar su extirpación mediante operación quirúrgica,
                                cuando se administran antes de la operación; y eliminar las células cancerosas que queden después de la operación quirúrgica, bien en el estómago o en los ganglios linfáticos.</p>
                            <p>Quimioterapia pre y posoperatoria (perioperatoria): El objetivo de la quimioterapia es usar los medicamentos para lograr la muerte de las células tumorales o limitar su crecimiento. No hay ningún fármaco ni combinación de fármacos
                                que se sepa que funciona de forma óptima para todos los pacientes. La elección debería analizarse durante la consulta multidisciplinaria, teniendo en cuenta la importante información descrita previamente.</p>
                            <p>Otras terapias adyuvantes: Las opciones que se indican a continuación también han mostrado algunos buenos resultados, pero se necesitan más pruebas para compararlos con la quimioterapia perioperatoria. Por lo tanto, están investigándose
                                en más profundidad.</p>
                            <ul class="secciones-enumeradas">
                                <li>Radioquimioterapia: Es la combinación de quimio y radioterapia. La radioterapia es un tratamiento antineoplásico que elimina las células cancerosas mediante la irradiación específicamente dirigida a la zona donde se encuentra
                                    el cáncer.</li>
                                <li>Quimioterapia adyuvante: La quimioterapia es administrada únicamente después de una operación quirúrgica. Algunos estudios realizados en Asia indican que los pacientes que reciben quimioterapia después de una operación
                                    quirúrgica vivieron más tiempo.</li>
                            </ul>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Plan de tratamiento para enfermedad inoperable localmente avanzada (estadios III y IV no resecables)</h2>
                            <p>Un tumor puede ser no resecable porque ha invadido estructuras en torno al estómago (comoalgunos vasos sanguíneos principales), porque se ha extendido a otras partes del cuerpo o porque el paciente no está suficientemente saludable
                                como para someterse a una operación quirúrgica de tal importancia.</p>
                            <p>Para pacientes con enfermedad no operable localmente avanzada, se recomienda quimioterapia para aliviar los síntomas. Después de ello, si los pacientes responden bien a la quimioterapia, pueden volver a ser evaluados para ver
                                si pueden someterse a una operación quirúrgica. La quimioterapia tiene como objetivo las células cancerosas de todo el cuerpo y se administra para eliminar las células tumorales o limitar su crecimiento.</p>
                            <p>Algunos pacientes pueden volver a evaluarse para ver si pueden someterse a una operación quirúrgica y también si podrían recibir radioquimioterapia neoadyuvante (antes de someterse a una operación quirúrgica), aunque esta estrategia
                                continúa en fase de investigación.</p>
                            <h2 class="centrar-texto brexia-color encabezados-brexia ">Plan de tratamiento para enfermedad inoperable localmente avanzada (estadios III y IV no resecables)</h2>
                            <p>En estos casos, el tumor ha invadido las estructuras que rodean el estómago o más de 15 ganglios linfáticos están afectados, o el cáncer de estómago se ha extendido a otras partes del cuerpo.</p>
                            <p>Para el tratamiento de los pacientes con cáncer de estómago en estadio avanzado o metastásico el objetivo principal del tratamiento es mantener o mejorar la calidad de vida. Debe ofrecerse a los pacientes un tratamiento sintomático
                                personalizado apropiado.</p>
                            <p>El tratamiento de los pacientes con cáncer de estómago en estadio IV se basa en tratamientos sistémicos que tienen como objetivo todas las células cancerosas del cuerpo, como la quimioterapia, y otros tratamientos más focalizados
                                como las terapias dirigidas. También se usan tratamientos que tienen como objetivo las células locales, como la cirugía o la radioterapia.</p>
                        </div>
                    </article>

                </div>
            </section>
            <div class="font-20 centrar-texto brexia-color maxW-40 ">
                <p class="fontW-700">Regresar al inicio de esta pestaña para obtener más información del Cáncer de Estomago</p>
            </div>
            <div class="centrar-texto">
            <a href="#"><button class="boton boton-brexia-footer">Regresar al inicio</button></a>
            </div>

            <?php include_once '../includes/templates/footer.php';?>




        </section>
        <!-- END SITE CONTENT -->

    </section>
    <!--####HEADER####-->

    <a href="#" class="scrollup"><i class="fas fa-angle-double-up fa-2x"></i></a>
    <!--####FOOTER####-->


    <!--Esta es la parte para el pop-up-->
    <div id="ventana-modal" class="modal">
        <div class="modal-contenido">

            <div class="header-imagen">
                <img src="/img/Doctores.webp" alt="Imagen Brexia">
            </div>
            <div class="paddingTop-2 paddingBottom-1 centrar-texto texto-principal">
                <p><strong>¿Quieres curar tu</strong></p>
                <p><strong>Cáncer de Estómago?</strong></p>
            </div>
            <div class="centrar-texto">
                <div  class="texto-secundario">
                    <P>Llámanos y un especialista en <strong>Cáncer</strong>
                    <P> <strong>de Estómago</strong> te dará un tratamiento</P>
                    <p>para <strong>curar tu cáncer.</strong> </p>
                </div>
                <a href="../contacto " class="boton-vino" style= "text-decoration:none;">Contáctanos</a>
                <div class="boton-no">
                    <a style="padding-bottom: 20px;" type="button" class="btn waves-effect" data-dismiss="modal">No, gracias</a>
                </div>
                <div  class="texto-secundario-2">
                    <p>Se parte de los + 1000 pacientes</p>
                    <p>que han logrado vencer el cáncer</p>
                    <p>gracias a los especialistas de Brexia.</p>
                </div>
                <div  class="texto-secundario-2 paddingTop-2 paddingBottom-2">
                    <p>Tu salud es primero, el cáncer no espera.</p>
                </div>
                <a style="font-size: 10px; font-weight: 700; color: black; letter-spacing:10px; text-decoration: none;" type="button" class=" waves-effect" data-dismiss="modal">CERRAR</a>
            </div>
        </div>
    </div>
    <!--Aqui termina la parte para el pop-up-->


    <script src="https://kit.fontawesome.com/3919625d45.js" crossorigin="anonymous"></script>
    <script src="../js/jquery-3.5.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
    <!-- ### EDITABLE JS/JQUERY INCLUDE ### -->
    <script src="../js/scripts.js "></script>

</body>


</html>