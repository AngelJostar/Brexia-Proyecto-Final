<!--####FOOTER####-->
<div class="centrar-texto text-footer mostrar-text ">
    <p class="fontW-400">El cáncer en ningún caso se debe de auto diagnosticar ni auto medicar. </p>
</div>
<footer class="relativo">
    <div class="linea"></div>
    <div class="contenedor footer-grid">
        <div class="contenedor-footer">
            <div class="footer-grid">
                <div class="centrar-texto llama-tel ">
                    <a href="tel:+5555238959"><p class = "fontW-700">Tel: (55) 5523 8959</p></a>
                </div>
                <div class="centrar-texto">
                    <a href="../contacto.php"><button class="boton boton-brexia-footer">Contacto</button></a>
                </div>
            </div>
            <div class="centrar-texto text-footer">
                <p class="paddingTop-3 paddingBottom-3 fontW-400">San Francisco 524, Col. Del Valle CDMX, México</p>
            </div>
        </div>
        <div class="contenedor-footer">
            <div class="centrar-texto text-footer ocultar-text ">
                <p class="fontW-400">El cáncer en ningún caso se debe de auto diagnosticar ni auto medicar. </p>
            </div>
            <div class="centrar-texto">
                <div class="redes-footer">
                    <div class="wow fadeInDown" data-wow-delay="0.1s">
                        <div class="widget">
                            <ul class="company-social">
                                <li class="social-facebook"><a href="https://www.facebook.com/CentroBrexia/?ref=br_rs"><i class="fab fa-facebook-f fa-2x"></i></a></li>
                                <li class="social-youtube"><a href="https://www.youtube.com/channel/UCTG33NkFEG3LtPXwwzJFXYA?view_as=subscriber"><i class="fab fa-youtube fa-2x"></i></a></li>
                                <li class="social-whatsapp"><a href="https://api.whatsapp.com/send?phone=5215551358125&text=%22Hola!%20me%20gustar%C3%ADa%20obtener%20mas%20informaci%C3%B3n%22"><i class="fab fa-whatsapp fa-2x"></i></a></li>
                                <li class="social-instagram"><a href="https://www.instagram.com/centro.brexia/?hl=es-la"><i class="fab fa-instagram fa-2x"></i></a></li>
                                <li class="social-twitter"><a href="https://twitter.com/Centro_Brexia"><i class="fab fa-twitter fa-2x"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="deepfooter">
        <p> Aviso de Privacidad/Mapa de Sitio/ Permiso COFEPRIS: 193300201A0691 / 193300201A0861</p>
    </div>

</footer>